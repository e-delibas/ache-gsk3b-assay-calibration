Supporting Data S1 — full-precision CSV tables
Study: Evaluating Three-Reference Offset and Shrinkage Calibration in AChE and GSK-3β Assays
Archive date: 2026-11-20

Files under outputs/ exactly match analysis/outputs/*.csv in the repository.
Source annotation: sources/heldout_sources.csv matches data/sources/heldout_sources.csv in the repository.
Original strict panel and source-verified panel are distinct. All additional tests are exploratory.
Full molecule feature snapshot and individual reference draws are in the public source repository, not duplicated here.

Files:
outputs/assay_size_distributions.csv: 6 rows; columns=target, size_group, assays, median_size, median_within_SD, median_range, median_scaffolds
outputs/augmented_by_document.csv: 533 rows; columns=target, scope, k, model, doc, mae, mse, level_mse, within_mse, rho, rank_defined
outputs/cat_sensitivity.csv: 12 rows; columns=target, design, seed, depth, trees, k, w, cal_mae, gain, lo, hi
outputs/document_characteristics.csv: 41 rows; columns=target, doc, assay, n, sd, potency_range, gain_over_mean, gain_over_raw, raw_rho
outputs/document_scaffolds_and_performance.csv: 41 rows; columns=target, doc, assay, n, sd, potency_range, gain_over_mean, gain_over_raw, raw_rho, scaffolds
outputs/error_components_by_subset.csv: 212 rows; columns=target, panel, model, raw_to_calibrated_level_share, mae, mse, level_mse, within_mse
outputs/figure3_data.csv: 16 rows; columns=panel, model, mse, level, within
outputs/gain_correlations.csv: 10 rows; columns=target, characteristic, spearman_with_gain
outputs/influence_and_provenance.csv: 106 rows; columns=target, panel, baseline, bca_low, bca_high, n, mean_gain, median_gain, low, high, wins, losses, sign_p
outputs/kernel_by_document.csv: 41 rows; columns=doc, target, reference_mae, calibrated_mae, gain, raw_rho
outputs/kernel_summary.csv: 2 rows; columns=target, development_loss, ridge, weight, calibrated_mae, mean_mae, raw_rho, gain, low, high
outputs/primary_by_document.csv: 369 rows; columns=target, doc, method, bias, mae, mse
outputs/primary_summary.csv: 18 rows; columns=target, method, bias, mae, mse
outputs/reservation_released_by_document.csv: 172 rows; columns=target, doc, model, mae, mse, level_mse, within_mse, rho, rank_defined
outputs/reservation_released_counts.csv: 2 rows; columns=target, observations, training_observations, w
outputs/shrinkage_weights.csv: 2 rows; columns=target, reference_weight
outputs/small_by_document.csv: 189 rows; columns=target, doc, method, bias, mae, mse
outputs/small_summary.csv: 18 rows; columns=target, method, bias, mae, mse
outputs/spearman_matched.csv: 2 rows; columns=target, rho_raw, rho_nearest, bca_low, bca_high, n, mean_gain, median_gain, low, high, wins, losses, sign_p
outputs/table2_by_panel.csv: 16 rows; columns=panel, documents, model, mae, rho
outputs/table3_both_contrasts.csv: 16 rows; columns=target, panel, baseline, bca_low, bca_high, n, mean_gain, median_gain, low, high, wins, losses, sign_p
outputs/tau_b_matched.csv: 2 rows; columns=target, n, gain, median, lower, upper, wins, sign_p
outputs/unit_audit_20.csv: 20 rows; columns=Compound Key, source_row, Standard Value, Standard Units, source_pM, checked_nM, standard_flag_api, all_exclusion_reasons, primary_retained, augmented_retained
outputs/unit_panel_contrasts.csv: 8 rows; columns=panel, documents, baseline, gain, low, high
