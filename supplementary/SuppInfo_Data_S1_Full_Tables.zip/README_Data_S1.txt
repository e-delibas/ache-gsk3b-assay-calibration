Supporting Data S1 — full-precision CSV tables
Study: Evaluating Three-Reference Offset and Shrinkage Calibration in AChE and GSK-3β Assays

Files under outputs/ correspond to the analysis/outputs/ directory in the accompanying research repository.
Source annotation: sources/heldout_sources.csv.
Strict and source-verified panels remain separate. Retrospective diagnostics are exploratory.

Table S10: outputs/nested_development_paired_summary.csv (eight comparison rows) and
outputs/nested_development_paired_by_document.csv (document-level matched differences, 4 pairs per document).
The primary paired reference-mean vs globally calibrated comparison contains 121 AChE and 51 GSK-3β documents (172 documents total).
Only the cached out-of-fold development predictions were used for Table S10; the underlying models were not retrained.

Files:
outputs/assay_size_distributions.csv: 6 rows; columns=target, size_group, assays, median_size, median_within_SD, median_range, median_scaffolds
outputs/augmented_by_document.csv: 533 rows; columns=target, scope, k, model, doc, mae, mse, level_mse, within_mse, rho, rank_defined
outputs/cat_sensitivity.csv: 12 rows; columns=target, design, seed, depth, trees, k, w, cal_mae, gain, lo, hi
outputs/document_characteristics.csv: 41 rows; columns=target, doc, assay, n, sd, potency_range, gain_over_mean, gain_over_raw, raw_rho
outputs/document_scaffolds_and_performance.csv: 41 rows; columns=target, doc, assay, n, sd, potency_range, gain_over_mean, gain_over_raw, raw_rho, scaffolds
outputs/error_components_by_subset.csv: 212 rows; columns=target, panel, model, raw_to_calibrated_level_share, mae, mse, level_mse, within_mse
outputs/figure3_data.csv: 16 rows; columns=panel, model, mse, level, within
outputs/gain_correlations.csv: 10 rows; columns=target, characteristic, spearman_with_gain
outputs/influence_and_provenance.csv: 106 rows; columns=target, panel, baseline, bca_low, bca_high, n, mean_gain, median_gain, low, high, wins, losses, sign_p
outputs/kernel_by_document.csv: 41 rows; columns=doc, target, reference_mae, calibrated_mae, gain, raw_rho
outputs/kernel_summary.csv: 2 rows; columns=target, development_loss, ridge, weight, calibrated_mae, mean_mae, raw_rho, gain, low, high
outputs/nested_development_paired_by_document.csv: 688 rows; columns=target, doc, baseline, model, mae_gain
outputs/nested_development_paired_summary.csv: 8 rows; columns=target, baseline, model, n_documents, mean_gain, median_gain, mean_ci_low, mean_ci_high, median_ci_low, median_ci_high, improved, worsened, ties, sign_test_p, baseline_mae, model_mae, positive_pct
outputs/primary_by_document.csv: 369 rows; columns=target, doc, method, bias, mae, mse
outputs/primary_summary.csv: 18 rows; columns=target, method, bias, mae, mse
outputs/reservation_released_by_document.csv: 172 rows; columns=target, doc, model, mae, mse, level_mse, within_mse, rho, rank_defined
outputs/reservation_released_counts.csv: 2 rows; columns=target, observations, training_observations, w
outputs/shrinkage_weights.csv: 2 rows; columns=target, reference_weight
outputs/small_by_document.csv: 189 rows; columns=target, doc, method, bias, mae, mse
outputs/small_summary.csv: 18 rows; columns=target, method, bias, mae, mse
outputs/spearman_matched.csv: 2 rows; columns=target, rho_raw, rho_nearest, bca_low, bca_high, n, mean_gain, median_gain, low, high, wins, losses, sign_p
outputs/table2_by_panel.csv: 16 rows; columns=panel, documents, model, mae, rho
outputs/table3_both_contrasts.csv: 16 rows; columns=target, panel, baseline, bca_low, bca_high, n, mean_gain, median_gain, low, high, wins, losses, sign_p
outputs/tau_b_matched.csv: 2 rows; columns=target, n, gain, median, lower, upper, wins, sign_p
outputs/unit_audit_20.csv: 20 rows; columns=Compound Key, source_row, Standard Value, Standard Units, source_pM, checked_nM, standard_flag_api, all_exclusion_reasons, primary_retained, augmented_retained
outputs/unit_panel_contrasts.csv: 8 rows; columns=panel, documents, baseline, gain, low, high
sources/heldout_sources.csv: 41 rows; columns=target, doc, assay, Assay Description, doc_type, title, doi, pubmed_id, patent_id, source_url, unknown, explicit_human, review, domain_issue, provenance_status
